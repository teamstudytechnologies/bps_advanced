package de.hft_stuttgart.DBAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import de.hft_stuttgart.BusinessObjects.Person;

public class DB_Personen {

	public static List<Person> listPerson = new ArrayList<Person>();
	static Connection conn = null;

	public static void DB_Verbindung() {

		String url = "jdbc:mysql://193.196.143.168:3306/";
		String dbName = "ohw8_gruppe2";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "ohw8_gruppe2";
		String password = "studytech";
		try {

			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, userName, password);
		}

		catch (Exception e) {

			e.printStackTrace();

		}

	}

	public static void getPersonen() {
		if (conn == null) {
			DB_Verbindung();
		}
		try {

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Personen");

			while (rs.next()) {

				Person person = new Person(rs.getString("Vorname"), rs.getString("Nachname"), rs.getString("EMail"),
						rs.getString("Passwort"), rs.getString("Status"), rs.getInt("Personen_ID"),
						rs.getInt("Praktikum_ID"), rs.getInt("HFT_Betreuer_ID"), rs.getBoolean("Berichtsstatus"));

				listPerson.add(person);

			}
			conn.close();

		} catch (Exception a) {
			a.printStackTrace();
		}
	}

	public static void setPerson(String vorname, String nachname, String email, String passwort, String status) {
		if (conn == null) {
			DB_Verbindung();
		}
		try {

			Statement stmt = conn.createStatement();
			stmt.executeUpdate("INSERT INTO Personen(Vorname,Nachname,EMail,Passwort,Status)  VALUE ('" + vorname
					+ "','" + nachname + "','" + email + "','" + passwort + "','" + status + "')");

			conn.close();
		}

		catch (Exception a) {
			a.printStackTrace();
		}

	}

}
