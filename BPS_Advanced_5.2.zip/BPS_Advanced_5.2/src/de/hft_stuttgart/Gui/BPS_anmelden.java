package de.hft_stuttgart.Gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import de.hft_stuttgart.DBAccess.DB_Praktikum;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JScrollPane;

public class BPS_anmelden extends JFrame {

	private JPanel contentPane;
	private JTextField textfield_Name;
	private JTextField textfield_Strasse;
	private JTextField textfield_Nr;
	private JTextField textfield_PLZ;
	private JTextField textfield_Ort;
	private JTextField textField_Firmenbetreuer;
	private JTextField textField_Termin;
	private JTextField textField_Datum;
	private JTextField textField_EMail;
	private JTextField textField_Abteilung;
	private JTextField textField_Telefon;
	private JTextField textField_vom;
	private JTextField textField_bis;
	private JTextField textField_Themenbereich;
	private JTextField textField_Kurzbeschreibung;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BPS_anmelden frame = new BPS_anmelden();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public BPS_anmelden() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 2, 2);
		contentPane.add(scrollPane);

		JLabel lblAnmeldungDesBps = new JLabel("Anmeldung des BPS");
		lblAnmeldungDesBps.setFont(new Font("Arial", Font.BOLD, 16));
		lblAnmeldungDesBps.setBounds(280, 11, 164, 20);
		contentPane.add(lblAnmeldungDesBps);

		JLabel plz = new JLabel("PLZ:");
		plz.setFont(new Font("Arial", Font.BOLD, 12));
		plz.setBounds(10, 126, 46, 14);
		contentPane.add(plz);

		JLabel unternehmensname = new JLabel("Unternehmensname:");
		unternehmensname.setFont(new Font("Arial", Font.BOLD, 12));
		unternehmensname.setBounds(10, 50, 135, 15);
		contentPane.add(unternehmensname);

		JLabel strasse = new JLabel("Stra\u00DFe:");
		strasse.setFont(new Font("Arial", Font.BOLD, 12));
		strasse.setBounds(10, 76, 46, 14);
		contentPane.add(strasse);

		JLabel nr = new JLabel("Nr.:");
		nr.setFont(new Font("Arial", Font.BOLD, 12));
		nr.setBounds(10, 101, 46, 14);
		contentPane.add(nr);

		JLabel ort = new JLabel("Ort:");
		ort.setFont(new Font("Arial", Font.BOLD, 12));
		ort.setBounds(10, 151, 46, 14);
		contentPane.add(ort);

		JLabel lblFirmenbetreuer = new JLabel("Firmenbetreuer:");
		lblFirmenbetreuer.setFont(new Font("Arial", Font.BOLD, 12));
		lblFirmenbetreuer.setBounds(10, 206, 109, 14);
		contentPane.add(lblFirmenbetreuer);

		JLabel lblAbteilung = new JLabel("Abteilung:");
		lblAbteilung.setFont(new Font("Arial", Font.BOLD, 12));
		lblAbteilung.setBounds(10, 231, 100, 14);
		contentPane.add(lblAbteilung);

		JLabel lblTelefon = new JLabel("Telefon:");
		lblTelefon.setFont(new Font("Arial", Font.BOLD, 12));
		lblTelefon.setBounds(10, 256, 46, 14);
		contentPane.add(lblTelefon);

		JLabel lblEmail = new JLabel("E-Mail:");
		lblEmail.setFont(new Font("Arial", Font.BOLD, 12));
		lblEmail.setBounds(10, 281, 46, 14);
		contentPane.add(lblEmail);

		JLabel lblVom = new JLabel("vom");
		lblVom.setFont(new Font("Arial", Font.BOLD, 12));
		lblVom.setBounds(488, 76, 30, 14);
		contentPane.add(lblVom);

		JLabel lblBis = new JLabel("bis");
		lblBis.setFont(new Font("Arial", Font.BOLD, 12));
		lblBis.setBounds(608, 76, 17, 14);
		contentPane.add(lblBis);

		JLabel lblTeilnahmeImSeptember = new JLabel("Teilnahme im September 2019");
		lblTeilnahmeImSeptember.setFont(new Font("Arial", Font.BOLD, 12));
		lblTeilnahmeImSeptember.setBounds(423, 125, 175, 14);
		contentPane.add(lblTeilnahmeImSeptember);

		JLabel lblBereitsAbsolviertandererTermin = new JLabel("Bereits absolviert/anderer Termin:");
		lblBereitsAbsolviertandererTermin.setFont(new Font("Arial", Font.BOLD, 12));
		lblBereitsAbsolviertandererTermin.setBounds(390, 175, 200, 14);
		contentPane.add(lblBereitsAbsolviertandererTermin);

		JLabel lblThemenbereichDesPraktikums = new JLabel("Themenbereich des Praktikums:");
		lblThemenbereichDesPraktikums.setFont(new Font("Arial", Font.BOLD, 12));
		lblThemenbereichDesPraktikums.setBounds(399, 212, 185, 14);
		contentPane.add(lblThemenbereichDesPraktikums);

		JLabel lblKurzbeschreibungDerGeplanten = new JLabel("Kurzbeschreibung der geplanten T\u00E4tigkeit:");
		lblKurzbeschreibungDerGeplanten.setFont(new Font("Arial", Font.BOLD, 12));
		lblKurzbeschreibungDerGeplanten.setBounds(458, 281, 240, 14);
		contentPane.add(lblKurzbeschreibungDerGeplanten);

		JLabel lblDatum = new JLabel("Datum:");
		lblDatum.setFont(new Font("Arial", Font.BOLD, 12));
		lblDatum.setBounds(534, 50, 50, 15);
		contentPane.add(lblDatum);

		textfield_Name = new JTextField();
		textfield_Name.setBounds(150, 49, 100, 20);
		contentPane.add(textfield_Name);
		textfield_Name.setColumns(10);

		textfield_Strasse = new JTextField();
		textfield_Strasse.setBounds(150, 75, 100, 20);
		contentPane.add(textfield_Strasse);
		textfield_Strasse.setColumns(10);

		textfield_Nr = new JTextField();
		textfield_Nr.setBounds(150, 100, 100, 20);
		contentPane.add(textfield_Nr);
		textfield_Nr.setColumns(10);

		textfield_PLZ = new JTextField();
		textfield_PLZ.setBounds(150, 125, 100, 20);
		contentPane.add(textfield_PLZ);
		textfield_PLZ.setColumns(10);

		textfield_Ort = new JTextField();
		textfield_Ort.setBounds(150, 150, 100, 20);
		contentPane.add(textfield_Ort);
		textfield_Ort.setColumns(10);

		textField_Firmenbetreuer = new JTextField();
		textField_Firmenbetreuer.setBounds(150, 200, 100, 20);
		contentPane.add(textField_Firmenbetreuer);
		textField_Firmenbetreuer.setColumns(10);

		textField_Termin = new JTextField();
		textField_Termin.setBounds(598, 173, 100, 20);
		contentPane.add(textField_Termin);
		textField_Termin.setColumns(10);

		textField_Datum = new JTextField();
		textField_Datum.setBounds(598, 48, 100, 20);
		contentPane.add(textField_Datum);
		textField_Datum.setColumns(10);

		textField_EMail = new JTextField();
		textField_EMail.setBounds(150, 279, 100, 20);
		contentPane.add(textField_EMail);
		textField_EMail.setColumns(10);

		textField_Abteilung = new JTextField();
		textField_Abteilung.setBounds(150, 229, 100, 20);
		contentPane.add(textField_Abteilung);
		textField_Abteilung.setColumns(10);

		textField_Telefon = new JTextField();
		textField_Telefon.setBounds(150, 254, 100, 20);
		contentPane.add(textField_Telefon);
		textField_Telefon.setColumns(10);

		textField_vom = new JTextField();
		textField_vom.setBounds(528, 74, 60, 20);
		contentPane.add(textField_vom);
		textField_vom.setColumns(10);

		textField_bis = new JTextField();
		textField_bis.setBounds(638, 73, 60, 20);
		contentPane.add(textField_bis);
		textField_bis.setColumns(10);

		textField_Themenbereich = new JTextField();
		textField_Themenbereich.setBounds(598, 210, 100, 20);
		contentPane.add(textField_Themenbereich);
		textField_Themenbereich.setColumns(10);

		textField_Kurzbeschreibung = new JTextField();
		textField_Kurzbeschreibung.setBounds(498, 316, 200, 60);
		contentPane.add(textField_Kurzbeschreibung);
		textField_Kurzbeschreibung.setColumns(10);

		JRadioButton rdbtnNewRadioButton = new JRadioButton("ja");
		rdbtnNewRadioButton.setBackground(new Color(255, 236, 215));
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setBounds(608, 126, 38, 15);
		contentPane.add(rdbtnNewRadioButton);

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("nein");
		rdbtnNewRadioButton_1.setBackground(new Color(255, 236, 215));
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setBounds(648, 126, 50, 15);
		contentPane.add(rdbtnNewRadioButton_1);

		JButton btnNewButton = new JButton("Abschicken");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(233, 53, 120));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				DB_Praktikum.setPraktikum(textfield_Name.getText(), textfield_Strasse.getText(),
						Integer.parseInt(textfield_Nr.getText()), Integer.parseInt(textfield_PLZ.getText()),
						textfield_Ort.getText());

				DB_Praktikum.PersonPraktikumVerbindung();

			}
		});
		btnNewButton.setBounds(423, 460, 125, 25);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("N\u00E4chste Seite");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(30, 144, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();
				Statusinformationen gui = new Statusinformationen();
				gui.setVisible(true);

			}
		});
		btnNewButton_1.setBounds(573, 460, 125, 25);
		contentPane.add(btnNewButton_1);
	}
}
