package de.hft_stuttgart.Gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Panel;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class Eintragung_Statusinfo extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Eintragung_Statusinfo frame = new Eintragung_Statusinfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Eintragung_Statusinfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBackground(new Color(255, 240, 224));
		panel.setBounds(75, 25, 600, 200);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblEintragungStudierende = new JLabel("Eintragung Studierende:");
		lblEintragungStudierende.setFont(new Font("Arial", Font.BOLD, 14));
		lblEintragungStudierende.setBounds(10, 10, 175, 20);
		panel.add(lblEintragungStudierende);

		JButton btnAbschicken = new JButton("Abschicken");
		btnAbschicken.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnAbschicken.setForeground(Color.WHITE);
		btnAbschicken.setBackground(new Color(233, 53, 120));
		btnAbschicken.setBounds(470, 160, 115, 25);
		panel.add(btnAbschicken);

		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 240, 224));
		panel_1.setBounds(75, 286, 600, 200);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("Statusinformation-Studierenden Zuweisung:");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 325, 20);
		panel_1.add(lblNewLabel);

		JButton btnNchsteSeite = new JButton("N\u00E4chste Seite");
		btnNchsteSeite.setForeground(Color.WHITE);
		btnNchsteSeite.setBackground(new Color(30, 144, 255));
		btnNchsteSeite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();
				Studierenden_Contact_1 gui6 = new Studierenden_Contact_1();
				gui6.setVisible(true);

			}
		});
		btnNchsteSeite.setBounds(470, 160, 115, 25);
		panel_1.add(btnNchsteSeite);

	}

}
