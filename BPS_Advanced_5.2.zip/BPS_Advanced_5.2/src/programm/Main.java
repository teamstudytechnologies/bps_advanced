package programm;

import java.awt.EventQueue;

import de.hft_stuttgart.Gui.BPS_Advanced_Login;

public class Main {

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BPS_Advanced_Login frame = new BPS_Advanced_Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}
}