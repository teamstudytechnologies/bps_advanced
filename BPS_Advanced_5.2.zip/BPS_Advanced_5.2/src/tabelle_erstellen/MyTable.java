package tabelle_erstellen;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

public class MyTable extends AbstractTableModel {

	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return 5;

	}

	@Override
	public Object getValueAt(int row, int col) {

		List<Person> listPerson = new ArrayList<>();

		listPerson.add(new Person("Eugen", "Ullmann", 1));
		listPerson.add(new Person("Sascha", "M�ller", 2));
		listPerson.add(new Person("Max", "Ullmann", 3));
		listPerson.add(new Person("Eugen", "Ulbricht", 4));
		listPerson.add(new Person("Daniel", "Mustermann", 5));

		return col == 0 ? listPerson.get(row).vorname
				: col == 1 ? listPerson.get(row).nachname : listPerson.get(row).nummer;

	}

}
