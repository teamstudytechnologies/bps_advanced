import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DB {

	public static List<Person> listPerson = new ArrayList<Person>();
	static Connection conn = null;
	Gui2 gui2 = new Gui2();

	public static void DB_Verbindung() {

		String url = "jdbc:mysql://193.196.143.168:3306/";
		String dbName = "ohw8_gruppe2";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "ohw8_gruppe2";
		String password = "studytech";
		try {

			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, userName, password);
		}

		catch (Exception e) {

			e.printStackTrace();

		}

	}

	public static void getPersonen() {
		if (conn == null) {
			DB_Verbindung();
		}
		try {

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Personen");

			while (rs.next()) {

				Person person = new Person(rs.getString("Vorname"), rs.getString("Nachname"), rs.getString("EMail"),
						rs.getString("Passwort"), rs.getString("Status"), rs.getInt("Personen_ID"));

				listPerson.add(person);

			}
			conn.close();

		} catch (Exception a) {
			a.printStackTrace();
		}
	}

	public static void setPerson(String vorname, String nachname, String email, String passwort, String status) {
		if (conn == null) {
			DB_Verbindung();
		}
		try {

			Statement stmt = conn.createStatement();
			stmt.executeUpdate("INSERT INTO Personen(Vorname,Nachname,EMail,Passwort,Status)  VALUE ('" + vorname
					+ "','" + nachname + "','" + email + "','" + passwort + "','" + status + "')");

			conn.close();
		}

		catch (Exception a) {
			a.printStackTrace();
		}

	}

}
