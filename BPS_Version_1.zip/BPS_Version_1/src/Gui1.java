import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Frame;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Gui1 extends JFrame {

	private JPanel contentPane;
	private JTextField Username;
	private JTextField Passwort;

	static Connection conn = null;
	static String url = "jdbc:mysql://193.196.143.168:3306/";
	static String dbName = "ohw8_gruppe2";
	static String driver = "com.mysql.jdbc.Driver";
	static String userName = "ohw8_gruppe2";
	static String password = "studytech";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui1 frame = new Gui1();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage("..\\Images\\Study_Technologies_icon.png"));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JLabel logo = new JLabel(new ImageIcon("..\\Images\\Study_Technologies_logo.png"));
		logo.setBounds(275, 0, 200, 200);
		contentPane.add(logo);

		Username = new JTextField();
		Username.setBounds(300, 300, 150, 20);
		contentPane.add(Username);
		Username.setColumns(10);

		Passwort = new JPasswordField();
		Passwort.setBounds(300, 340, 150, 20);
		contentPane.add(Passwort);
		Passwort.setColumns(10);

		JLabel xing = new JLabel("");
		xing.setIcon(new ImageIcon("..\\Images\\xing_logo.png"));
		xing.setBounds(280, 200, 50, 50);
		contentPane.add(xing);

		JLabel google = new JLabel("");
		google.setIcon(new ImageIcon("..\\Images\\google_logo.png"));
		google.setBounds(350, 200, 50, 50);
		contentPane.add(google);

		JLabel facebook = new JLabel("");
		facebook.setIcon(new ImageIcon("..\\Images\\facebook_logo.png"));
		facebook.setBounds(420, 200, 50, 50);
		contentPane.add(facebook);

		JButton Account_erstellen = new JButton("Neuen Account erstellen");
		Account_erstellen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();
				Gui2 gui2 = new Gui2();
				gui2.setVisible(true);

			}
		});
		Account_erstellen.setBounds(300, 420, 150, 25);
		contentPane.add(Account_erstellen);

		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(200, 300, 75, 20);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Passwort:");
		lblNewLabel_1.setBounds(200, 340, 75, 20);
		contentPane.add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(325, 375, 100, 25);
		contentPane.add(btnNewButton);

		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				DB.getPersonen();

				boolean a = false;
				loop: for (int i = 0; i < DB.listPerson.size(); i++) {

					if (Username.getText().equals(DB.listPerson.get(i).getEmail().toString())
							&& Passwort.getText().equals(DB.listPerson.get(i).getPasswort().toString())) {
						a = true;

						switch (DB.listPerson.get(i).getStatus()) {
						case "Student":
							dispose();
							Gui3 gui3 = new Gui3();
							gui3.setVisible(true);

							break loop;

						case "Professor":
							dispose();
							Gui5 gui5 = new Gui5();
							gui5.setVisible(true);
							break loop;
						default:
							break;
						}

					}

				}

				if (a == false) {
					JOptionPane.showMessageDialog(null, "fail");
				}

			}
		});

	}
}
