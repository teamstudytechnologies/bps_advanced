import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Gui2 extends JFrame {

	private JPanel contentPane;
	public static JTextField Vorname;
	public static JTextField Nachname;
	public static JTextField EMail;
	public static JTextField Passwort;
	public static JTextField Status;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui2 frame = new Gui2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui2() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage("..\\Images\\Study_Technologies_icon.png"));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Vorname");
		lblNewLabel.setBounds(50, 150, 75, 20);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Nachname");
		lblNewLabel_1.setBounds(50, 200, 75, 20);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("E-Mail");
		lblNewLabel_2.setBounds(50, 250, 75, 20);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Passwort");
		lblNewLabel_3.setBounds(50, 300, 75, 20);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Status");
		lblNewLabel_4.setBounds(50, 350, 75, 20);
		contentPane.add(lblNewLabel_4);

		JLabel lblRegistration = new JLabel("Registration");
		lblRegistration.setBounds(325, 50, 75, 20);
		contentPane.add(lblRegistration);

		Vorname = new JTextField();
		Vorname.setBounds(175, 150, 300, 20);
		contentPane.add(Vorname);
		Vorname.setColumns(10);

		Nachname = new JTextField();
		Nachname.setBounds(175, 200, 300, 20);
		contentPane.add(Nachname);
		Nachname.setColumns(10);

		EMail = new JTextField();
		EMail.setBounds(175, 250, 300, 20);
		contentPane.add(EMail);
		EMail.setColumns(10);

		Passwort = new JPasswordField();
		Passwort.setBounds(175, 300, 300, 20);
		contentPane.add(Passwort);
		Passwort.setColumns(10);

		Status = new JTextField();
		Status.setBounds(175, 350, 300, 20);
		contentPane.add(Status);
		Status.setColumns(10);

		JButton btnAnlegen = new JButton("Anlegen");
		btnAnlegen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DB.setPerson(Vorname.getText(),Nachname.getText(),EMail.getText(),Passwort.getText(),Status.getText());
				
				JOptionPane.showMessageDialog(null, "Sie haben sich erfolgreich registriert");
				
				dispose();
				Gui3 gui3 = new Gui3();
				gui3.setVisible(true);
			}
		});
		btnAnlegen.setBounds(561, 430, 100, 20);
		contentPane.add(btnAnlegen);

	}
}
