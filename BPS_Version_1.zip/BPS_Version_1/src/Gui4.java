import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Panel;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Gui4 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui4 frame = new Gui4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui4() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage("..\\Images\\Study_Technologies_icon.png"));
		
		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBackground(new Color(255, 240, 224));
		panel.setBounds(75, 25, 600, 200);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblBetreuerKontaktieren = new JLabel("Betreuer kontaktieren:");
		lblBetreuerKontaktieren.setBounds(10, 11, 138, 14);
		panel.add(lblBetreuerKontaktieren);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 240, 224));
		panel_1.setBounds(75, 286, 600, 200);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblBerichtUpload = new JLabel("Bericht Upload:");
		lblBerichtUpload.setBounds(10, 11, 137, 14);
		panel_1.add(lblBerichtUpload);
	}

}
