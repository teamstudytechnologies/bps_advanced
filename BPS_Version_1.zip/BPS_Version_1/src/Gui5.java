import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Panel;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Gui5 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui5 frame = new Gui5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui5() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage("..\\Images\\Study_Technologies_icon.png"));
		
		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBackground(new Color(255, 240, 224));
		panel.setBounds(75, 25, 600, 200);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblEintragungStudierende = new JLabel("Eintragung Studierende");
		lblEintragungStudierende.setBounds(10, 11, 167, 14);
		panel.add(lblEintragungStudierende);
		
		JButton btnAbschicken = new JButton("Abschicken");
		btnAbschicken.setBounds(390, 153, 156, 23);
		panel.add(btnAbschicken);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 240, 224));
		panel_1.setBounds(75, 286, 600, 200);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Statusinformation-Studierenden Zuweisung");
		lblNewLabel.setBounds(23, 11, 249, 14);
		panel_1.add(lblNewLabel);
		
		JButton btnNchsteSeite = new JButton("N\u00E4chste Seite");
		btnNchsteSeite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				Gui6 gui6 = new Gui6();
				gui6.setVisible(true);
				
			}
		});
		btnNchsteSeite.setBounds(310, 153, 240, 23);
		panel_1.add(btnNchsteSeite);
		
	}

}
