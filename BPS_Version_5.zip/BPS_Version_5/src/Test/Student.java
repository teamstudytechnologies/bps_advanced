package Test;

import java.util.ArrayList;
import java.util.List;

public class Student {
	public static List<Student> listStudent = new ArrayList<>();
	String vorname,nachname,status;
	

	
	
	
	
	public Student(String vorname, String nachname, String status) {
		super();
		this.vorname = vorname;
		this.nachname = nachname;
		this.status = status;
	}






	public static void main(String[] args) {
		
		Student person = new Student ("Eugen","Ullmann","Student"); 
		
		Student person1 = new Student ("Sascha","Ullmann","Student"); 
		Student person2 = new Student ("Sascha","Ullmann","Professor"); 
		
		
		listStudent.add(person);
		listStudent.add(person1);
		listStudent.add(person2);
		
		System.out.println((int) listStudent.stream().filter(s -> s.status.equals("Student")).count());

		
	}

}
