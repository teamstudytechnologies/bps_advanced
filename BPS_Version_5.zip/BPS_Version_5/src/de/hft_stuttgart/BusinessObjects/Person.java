package de.hft_stuttgart.BusinessObjects;

public class Person {

	@Override
	public String toString() {
		return vorname + " " + nachname;
	}
	
	
	

	private String vorname, nachname, email, passwort, status;
	private int person_id;
	private int praktikum_id;
	private int betreuer_id;
	private boolean berichtsstatus;

	public Person(String vorname, String nachname, String email, String passwort, String status, int person_id,
			int praktikum_id, int betreuer_id, boolean berichtsstatus) {
		super();
		this.vorname = vorname;
		this.nachname = nachname;
		this.email = email;
		this.passwort = passwort;
		this.status = status;
		this.person_id = person_id;
		this.praktikum_id = praktikum_id;
		this.betreuer_id = betreuer_id;
		this.berichtsstatus = berichtsstatus;
	}

	public Person(String vorname, String nachname, String email, String passwort, String status) {
		super();
		this.vorname = vorname;
		this.nachname = nachname;
		this.email = email;
		this.passwort = passwort;
		this.status = status;
	}

	public boolean isBerichtsstatus() {
		return berichtsstatus;
	}

	public void setBerichtsstatus(boolean berichtsstatus) {
		this.berichtsstatus = berichtsstatus;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPasswort() {
		return passwort;
	}

	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPerson_id() {
		return person_id;
	}

	public void setPerson_id(int person_id) {
		this.person_id = person_id;
	}

	public int getPraktikum_id() {
		return praktikum_id;
	}

	public void setPraktikum_id(int praktikum_id) {
		this.praktikum_id = praktikum_id;
	}

	public int getBetreuer_id() {
		return betreuer_id;
	}

	public void setBetreuer_id(int betreuer_id) {
		this.betreuer_id = betreuer_id;
	}

}
