package de.hft_stuttgart.DBAccess;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import de.hft_stuttgart.Gui.Startfenster;

public class DB_Praktikum {

	static Connection conn = null;

	public static void DB_Verbindung() {

		String url = "jdbc:mysql://193.196.143.168:3306/";
		String dbName = "ohw8_gruppe2";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "ohw8_gruppe2";
		String password = "studytech";
		try {

			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, userName, password);
		}

		catch (Exception e) {

			e.printStackTrace();

		}

	}

	public static void setPraktikum(String name, String strasse, int nummer, int plz, String ort) {
		if (conn == null) {
			DB_Verbindung();
		}
		try {

			Statement stmt = conn.createStatement();
			stmt.executeUpdate("INSERT INTO Praktikumsstelle(Name,Stra�e,Nummer,PLZ,Ort)  VALUE ('" + name + "','"
					+ strasse + "','" + nummer + "','" + plz + "','" + ort + "')");

			conn.close();
		}

		catch (Exception a) {
			a.printStackTrace();
		}

	}

	public static void PersonPraktikumVerbindung() {

		try {
			if (conn.isClosed()) {
				DB_Verbindung();
			}

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT MAX(Praktikumsstellen_ID) as id FROM Praktikumsstelle");

			while (rs.next()) {

				int highest_id = rs.getInt("id");

				Statement stmt2 = conn.createStatement();
				stmt2.executeUpdate(
						"UPDATE Personen SET Praktikum_ID='" + highest_id + "' WHERE Personen_ID='" + Startfenster.eingeloggtePerson.getPerson_id() + "'");
			}

			conn.close();
		}

		catch (Exception a) {
			a.printStackTrace();
		}

	}

}
