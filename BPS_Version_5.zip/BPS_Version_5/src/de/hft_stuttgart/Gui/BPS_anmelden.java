package de.hft_stuttgart.Gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import de.hft_stuttgart.DBAccess.DB_Praktikum;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JScrollPane;

public class BPS_anmelden extends JFrame {

	private JPanel contentPane;
	private JTextField textfieldName;
	private JTextField textfieldStrasse;
	private JTextField textfieldNr;
	private JTextField textfieldPLZ;
	private JTextField textfieldOrt;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BPS_anmelden frame = new BPS_anmelden();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BPS_anmelden() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 2, 2);
		contentPane.add(scrollPane);

		JLabel lblAnmeldungDesBps = new JLabel("Anmeldung des BPS");
		lblAnmeldungDesBps.setFont(new Font("Dialog", Font.BOLD, 16));
		lblAnmeldungDesBps.setBounds(275, 11, 200, 20);
		contentPane.add(lblAnmeldungDesBps);

		JLabel plz = new JLabel("PLZ:");
		plz.setFont(new Font("Dialog", Font.BOLD, 12));
		plz.setBounds(10, 125, 46, 14);
		contentPane.add(plz);

		JLabel unternehmensname = new JLabel("Unternehmensname:");
		unternehmensname.setFont(new Font("Dialog", Font.BOLD, 12));
		unternehmensname.setBounds(10, 50, 135, 15);
		contentPane.add(unternehmensname);

		JLabel strasse = new JLabel("Stra\u00DFe:");
		strasse.setFont(new Font("Dialog", Font.BOLD, 12));
		strasse.setBounds(10, 75, 46, 14);
		contentPane.add(strasse);

		JLabel nr = new JLabel("Nr.:");
		nr.setFont(new Font("Dialog", Font.BOLD, 12));
		nr.setBounds(10, 100, 46, 14);
		contentPane.add(nr);

		JLabel ort = new JLabel("Ort:");
		ort.setFont(new Font("Dialog", Font.BOLD, 12));
		ort.setBounds(10, 150, 46, 14);
		contentPane.add(ort);

		JLabel lblFirmenbetreuer = new JLabel("Firmenbetreuer:");
		lblFirmenbetreuer.setFont(new Font("Dialog", Font.BOLD, 12));
		lblFirmenbetreuer.setBounds(10, 175, 109, 14);
		contentPane.add(lblFirmenbetreuer);

		JLabel lblAbteilung = new JLabel("Abteilung:");
		lblAbteilung.setFont(new Font("Dialog", Font.BOLD, 12));
		lblAbteilung.setBounds(10, 200, 100, 14);
		contentPane.add(lblAbteilung);

		JLabel lblTelefon = new JLabel("Telefon:");
		lblTelefon.setFont(new Font("Dialog", Font.BOLD, 12));
		lblTelefon.setBounds(10, 225, 46, 14);
		contentPane.add(lblTelefon);

		JLabel lblEmail = new JLabel("E-Mail:");
		lblEmail.setFont(new Font("Dialog", Font.BOLD, 12));
		lblEmail.setBounds(10, 250, 46, 14);
		contentPane.add(lblEmail);

		JLabel lblVom = new JLabel("vom");
		lblVom.setFont(new Font("Dialog", Font.BOLD, 12));
		lblVom.setBounds(10, 275, 30, 14);
		contentPane.add(lblVom);

		JLabel lblBis = new JLabel("bis");
		lblBis.setFont(new Font("Dialog", Font.BOLD, 12));
		lblBis.setBounds(125, 275, 30, 14);
		contentPane.add(lblBis);

		JLabel lblTeilnahmeImSeptember = new JLabel("Teilnahme im September 2019");
		lblTeilnahmeImSeptember.setFont(new Font("Dialog", Font.BOLD, 12));
		lblTeilnahmeImSeptember.setBounds(10, 300, 175, 14);
		contentPane.add(lblTeilnahmeImSeptember);

		JLabel lblBereitsAbsolviertandererTermin = new JLabel("Bereits absolviert/anderer Termin");
		lblBereitsAbsolviertandererTermin.setFont(new Font("Dialog", Font.BOLD, 12));
		lblBereitsAbsolviertandererTermin.setBounds(10, 325, 223, 14);
		contentPane.add(lblBereitsAbsolviertandererTermin);

		JLabel lblThemenbereichDesPraktikums = new JLabel("Themenbereich des Praktikums");
		lblThemenbereichDesPraktikums.setFont(new Font("Dialog", Font.BOLD, 12));
		lblThemenbereichDesPraktikums.setBounds(10, 350, 206, 14);
		contentPane.add(lblThemenbereichDesPraktikums);

		JLabel lblKurzbeschreibungDerGeplanten = new JLabel("Kurzbeschreibung der geplanten T\u00E4tigkeit ");
		lblKurzbeschreibungDerGeplanten.setFont(new Font("Dialog", Font.BOLD, 12));
		lblKurzbeschreibungDerGeplanten.setBounds(10, 375, 268, 14);
		contentPane.add(lblKurzbeschreibungDerGeplanten);

		JLabel lblDatum = new JLabel("Datum:");
		lblDatum.setFont(new Font("Dialog", Font.BOLD, 12));
		lblDatum.setBounds(10, 475, 50, 15);
		contentPane.add(lblDatum);

		textfieldName = new JTextField();
		textfieldName.setBounds(150, 49, 100, 15);
		contentPane.add(textfieldName);
		textfieldName.setColumns(10);

		textfieldStrasse = new JTextField();
		textfieldStrasse.setBounds(150, 75, 100, 15);
		contentPane.add(textfieldStrasse);
		textfieldStrasse.setColumns(10);

		textfieldNr = new JTextField();
		textfieldNr.setBounds(150, 100, 100, 15);
		contentPane.add(textfieldNr);
		textfieldNr.setColumns(10);

		textfieldPLZ = new JTextField();
		textfieldPLZ.setBounds(150, 125, 100, 15);
		contentPane.add(textfieldPLZ);
		textfieldPLZ.setColumns(10);

		textfieldOrt = new JTextField();
		textfieldOrt.setBounds(150, 150, 100, 15);
		contentPane.add(textfieldOrt);
		textfieldOrt.setColumns(10);

		textField_5 = new JTextField();
		textField_5.setBounds(150, 175, 100, 15);
		contentPane.add(textField_5);
		textField_5.setColumns(10);

		textField_6 = new JTextField();
		textField_6.setBounds(200, 325, 100, 15);
		contentPane.add(textField_6);
		textField_6.setColumns(10);

		textField_7 = new JTextField();
		textField_7.setBounds(75, 475, 100, 15);
		contentPane.add(textField_7);
		textField_7.setColumns(10);

		textField_9 = new JTextField();
		textField_9.setBounds(150, 250, 100, 15);
		contentPane.add(textField_9);
		textField_9.setColumns(10);

		textField_10 = new JTextField();
		textField_10.setBounds(150, 200, 100, 15);
		contentPane.add(textField_10);
		textField_10.setColumns(10);

		textField_11 = new JTextField();
		textField_11.setBounds(150, 225, 100, 15);
		contentPane.add(textField_11);
		textField_11.setColumns(10);

		textField_12 = new JTextField();
		textField_12.setBounds(50, 275, 60, 15);
		contentPane.add(textField_12);
		textField_12.setColumns(10);

		textField_13 = new JTextField();
		textField_13.setBounds(160, 275, 60, 15);
		contentPane.add(textField_13);
		textField_13.setColumns(10);

		textField_14 = new JTextField();
		textField_14.setBounds(200, 350, 100, 15);
		contentPane.add(textField_14);
		textField_14.setColumns(10);

		textField_15 = new JTextField();
		textField_15.setBounds(10, 400, 200, 60);
		contentPane.add(textField_15);
		textField_15.setColumns(10);

		JRadioButton rdbtnNewRadioButton = new JRadioButton("ja");
		rdbtnNewRadioButton.setBackground(new Color(255, 236, 215));
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setBounds(205, 300, 50, 15);
		contentPane.add(rdbtnNewRadioButton);

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("nein");
		rdbtnNewRadioButton_1.setBackground(new Color(255, 236, 215));
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setBounds(280, 300, 50, 15);
		contentPane.add(rdbtnNewRadioButton_1);

		JButton btnNewButton = new JButton("Abschicken");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(233, 53, 120));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				DB_Praktikum.setPraktikum(textfieldName.getText(), textfieldStrasse.getText(),
						Integer.parseInt(textfieldNr.getText()), Integer.parseInt(textfieldPLZ.getText()),
						textfieldOrt.getText());

				DB_Praktikum.PersonPraktikumVerbindung();

			}
		});
		btnNewButton.setBounds(425, 460, 125, 25);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("N\u00E4chste Seite");
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(30, 144, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();
				Statusinformationen gui = new Statusinformationen();
				gui.setVisible(true);

			}
		});
		btnNewButton_1.setBounds(575, 460, 125, 25);
		contentPane.add(btnNewButton_1);
	}
}
