package de.hft_stuttgart.Gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Betreuer_kontaktieren extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Betreuer_kontaktieren frame = new Betreuer_kontaktieren();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Betreuer_kontaktieren() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JLabel lblBetreuerKontaktieren = new JLabel("Betreuer kontaktieren:");
		lblBetreuerKontaktieren.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblBetreuerKontaktieren.setHorizontalAlignment(SwingConstants.LEFT);
		lblBetreuerKontaktieren.setBounds(10, 25, 225, 25);
		contentPane.add(lblBetreuerKontaktieren);

		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setBounds(10, 73, 714, 351);
		contentPane.add(textArea);

		JButton btnSenden = new JButton("Senden");
		btnSenden.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();
				Gui4 gui4 = new Gui4();
				gui4.setVisible(true);

			}
		});
		btnSenden.setBounds(635, 435, 89, 23);
		contentPane.add(btnSenden);
	}
}
