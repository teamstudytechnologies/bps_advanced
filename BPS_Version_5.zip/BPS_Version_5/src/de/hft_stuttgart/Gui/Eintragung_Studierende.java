package de.hft_stuttgart.Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.Enumeration;

import javax.swing.DefaultCellEditor;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableColumnModelListener;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Eintragung_Studierende extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Eintragung_Studierende frame = new Eintragung_Studierende();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Eintragung_Studierende() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));
		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);
		

		JTable table = new JTable(new MyTable());

		String[] a = { "Vorname", "Nachname", "E-Mail", "HfT-Betreuer" };

		for (int i = 0; i < a.length; i++) {

			TableColumn tc = table.getColumnModel().getColumn(i);
			tc.setHeaderValue(a[i]);
		}

		JScrollPane scrollpane = new JScrollPane(table);
		scrollpane.setBounds(25, 76, 682, 369);
		
		
		
		//TableColumn tc = table.getColumnModel().getColumn(3);
	    //tc.setCellEditor(table.getDefaultEditor(Boolean.class));
	    //tc.setCellRenderer(table.getDefaultRenderer(Boolean.class));
		
		scrollpane.getViewport().setBackground(new Color(255, 236, 215));
		contentPane.add(scrollpane);
		
		JLabel lblEintragungStudierende = new JLabel("Eintragung Studierende");
		lblEintragungStudierende.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblEintragungStudierende.setHorizontalAlignment(SwingConstants.CENTER);
		lblEintragungStudierende.setBounds(49, 24, 658, 41);
		contentPane.add(lblEintragungStudierende);
		
		JButton btnNchsteSeite = new JButton("N\u00E4chste Seite");
		btnNchsteSeite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				
				Gui5 gui5 = new Gui5();
				gui5.setVisible(true);
				
			}
		});
		btnNchsteSeite.setBounds(550, 456, 157, 30);
		contentPane.add(btnNchsteSeite);
		
		
	}
}
