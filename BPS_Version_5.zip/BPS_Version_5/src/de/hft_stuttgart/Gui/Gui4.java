package de.hft_stuttgart.Gui;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

public class Gui4 extends JFrame {
	static int person_id;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui4 frame = new Gui4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui4() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBackground(new Color(255, 240, 224));
		panel.setBounds(75, 25, 600, 200);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblBetreuerKontaktieren = new JLabel("Betreuer kontaktieren:");
		lblBetreuerKontaktieren.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBetreuerKontaktieren.setBounds(10, 10, 175, 20);
		panel.add(lblBetreuerKontaktieren);

		JButton btnNewButton_1 = new JButton("HFT Betreuer kontaktieren");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();

				Betreuer_kontaktieren gui = new Betreuer_kontaktieren();
				gui.setVisible(true);

			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(233, 53, 120));
		btnNewButton_1.setBounds(10, 50, 200, 30);
		panel.add(btnNewButton_1);

		JLabel lblNewLabel = new JLabel("Prof M\u00FCller");
		lblNewLabel.setBackground(new Color(175, 238, 238));
		lblNewLabel.setOpaque(true);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 115, 200, 52);
		panel.add(lblNewLabel);

		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 240, 224));
		panel_1.setBounds(75, 286, 600, 200);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblBerichtUpload = new JLabel("Bericht Upload:");
		lblBerichtUpload.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBerichtUpload.setBounds(10, 10, 125, 20);
		panel_1.add(lblBerichtUpload);
		
		JLabel Berichtsstatus = new JLabel("Bericht noch nicht hochgeladen");
		Berichtsstatus.setBackground(Color.LIGHT_GRAY);
		Berichtsstatus.setOpaque(true);
		Berichtsstatus.setHorizontalAlignment(SwingConstants.CENTER);
		Berichtsstatus.setBounds(345, 67, 228, 30);
		panel_1.add(Berichtsstatus);
		
		if(Startfenster.eingeloggtePerson.isBerichtsstatus()==false) {
			Berichtsstatus.setText("Bericht ist nicht in Ordnung");
			Berichtsstatus.setBackground(Color.RED);
		}
		
		if(Startfenster.eingeloggtePerson.isBerichtsstatus()==true) {
			Berichtsstatus.setText("Bericht ist in Ordnung");
			Berichtsstatus.setBackground(Color.GREEN);
		}
		
		
		

		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();
				Statusinformationen gui = new Statusinformationen();
				gui.setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(255, 236, 215));
		btnNewButton.setBackground(new Color(255, 236, 215));
		btnNewButton.setIcon(new ImageIcon(this.getClass().getResource("/back-icon.png")));
		btnNewButton.setBounds(44, 25, 25, 25);
		contentPane.add(btnNewButton);
	}
}
