package de.hft_stuttgart.Gui;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;

public class Gui6 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui6 frame = new Gui6();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui6() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(this.getClass().getResource("/Study_Technologies_icon.png")));
		
		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBackground(new Color(255, 240, 224));
		panel.setBounds(75, 25, 600, 200);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblStudierendeKontaktieren = new JLabel("Studierende kontaktieren");
		lblStudierendeKontaktieren.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblStudierendeKontaktieren.setBounds(10, 11, 241, 14);
		panel.add(lblStudierendeKontaktieren);
		
		JLabel lblRckmeldungZumPraktikumsbericht = new JLabel("R\u00FCckmeldung zum Praktikumsbericht");
		lblRckmeldungZumPraktikumsbericht.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblRckmeldungZumPraktikumsbericht.setBounds(283, 11, 307, 14);
		panel.add(lblRckmeldungZumPraktikumsbericht);
		
		JButton btnStudierendenKontaktieren = new JButton("Studierenden kontaktieren ");
		btnStudierendenKontaktieren.setBackground(new Color(233, 53, 120));
		btnStudierendenKontaktieren.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Studierenden_kontaktieren gui = new Studierenden_kontaktieren();
				gui.setVisible(true);
				
			}
		});
		btnStudierendenKontaktieren.setBounds(10, 48, 202, 30);
		panel.add(btnStudierendenKontaktieren);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 240, 224));
		panel_1.setBounds(75, 286, 600, 200);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblBesuchsbericht = new JLabel("Besuchsbericht");
		lblBesuchsbericht.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblBesuchsbericht.setBounds(10, 11, 182, 14);
		panel_1.add(lblBesuchsbericht);
		
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 36, 580, 153);
		panel_1.add(textArea);
		textArea.setLineWrap(true);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				Gui5 gui5 = new Gui5();
				gui5.setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(255, 236, 215));
		btnNewButton.setBackground(new Color(255, 236, 215));
		btnNewButton.setIcon(new ImageIcon(this.getClass().getResource("/back-icon.png")));
		btnNewButton.setBounds(44, 25, 25, 25);
		contentPane.add(btnNewButton);
		
	}
}
