package de.hft_stuttgart.Gui;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import de.hft_stuttgart.BusinessObjects.Person;
import de.hft_stuttgart.DBAccess.DB_Personen;

public class MyTable extends AbstractTableModel {

	int StudentenAnzahl = (int) DB_Personen.listPerson.stream().filter(s -> s.getStatus().equals("Student")).count();

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub

		return StudentenAnzahl;

	}

	/*@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch (columnIndex) {
		case 0:
			return String.class;
		case 1:
			return String.class;
		case 2:
			return String.class;
		case 3:
			return Boolean.class;
		default:
			throw new UnsupportedOperationException("no such column: " + columnIndex);
		}
	}*/

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		List<Person> listStudent = new ArrayList<Person>();
		for (int i = 0; i < DB_Personen.listPerson.size(); i++) {
			if (DB_Personen.listPerson.get(i).getStatus().equals("Student")) {
				listStudent.add(DB_Personen.listPerson.get(i));
			}
		}
		switch (columnIndex) {
		case 0:
			return listStudent.get(rowIndex).getVorname();
		case 1:
			return listStudent.get(rowIndex).getNachname();
		case 2:
			return listStudent.get(rowIndex).getEmail();
		case 3:
			if (listStudent.get(rowIndex).getBetreuer_id()==0) {
				return "Keiner";
			}
			else {
				return listStudent.get(rowIndex).getBetreuer_id();				
			}
			
		}
		return null;
	}
}
