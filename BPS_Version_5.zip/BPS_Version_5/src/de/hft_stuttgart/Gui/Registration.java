package de.hft_stuttgart.Gui;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import de.hft_stuttgart.BusinessObjects.Person;
import de.hft_stuttgart.DBAccess.DB_Personen;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.SwingConstants;

public class Registration extends JFrame {

	private JPanel contentPane;
	public static JTextField Vorname;
	public static JTextField Nachname;
	public static JTextField EMail;
	public static JTextField Passwort;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration frame = new Registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Registration() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Vorname:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(100, 150, 75, 25);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Nachname:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(100, 200, 75, 25);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("E-Mail:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(100, 250, 75, 25);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Passwort:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(100, 300, 75, 25);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Rolle:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(100, 350, 75, 25);
		contentPane.add(lblNewLabel_4);

		JLabel lblRegistration = new JLabel("Registration");
		lblRegistration.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistration.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblRegistration.setBounds(300, 50, 150, 25);
		contentPane.add(lblRegistration);

		Vorname = new JTextField();
		Vorname.setBounds(225, 150, 300, 25);
		contentPane.add(Vorname);
		Vorname.setColumns(10);

		Nachname = new JTextField();
		Nachname.setBounds(225, 200, 300, 25);
		contentPane.add(Nachname);
		Nachname.setColumns(10);

		EMail = new JTextField();
		EMail.setBounds(225, 250, 300, 25);
		contentPane.add(EMail);
		EMail.setColumns(10);

		Passwort = new JPasswordField();
		Passwort.setBounds(225, 300, 300, 25);
		contentPane.add(Passwort);
		Passwort.setColumns(10);

		String[] optionStatus = new String[] { "Student", "Professor" };
		JComboBox Status = new JComboBox(optionStatus);
		Status.setBounds(225, 350, 300, 25);
		contentPane.add(Status);

		JButton btnAnlegen = new JButton("Anlegen");
		btnAnlegen.setForeground(Color.WHITE);
		btnAnlegen.setBackground(new Color(233, 53, 120));
		btnAnlegen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DB_Personen.setPerson(Vorname.getText(), Nachname.getText(), EMail.getText(), Passwort.getText(),
						Status.getSelectedItem().toString());
				
				Startfenster.eingeloggtePerson = new Person(Vorname.getText(), Nachname.getText(), EMail.getText(), Passwort.getText(), 
						Status.getSelectedItem().toString());

				if (Status.getSelectedItem().equals("Student")) {
					JOptionPane.showMessageDialog(null, "Sie haben sich erfolgreich registriert");

					dispose();
					BPS_anmelden anmelden = new BPS_anmelden();
					anmelden.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Sie haben sich erfolgreich registriert");

					dispose();
					Gui5 gui5 = new Gui5();
					gui5.setVisible(true);
				}

			}
		});
		btnAnlegen.setBounds(575, 425, 100, 30);
		contentPane.add(btnAnlegen);

		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();
				Startfenster gui1 = new Startfenster();
				gui1.setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(255, 236, 215));
		btnNewButton.setBackground(new Color(255, 236, 215));
		btnNewButton.setIcon(new ImageIcon(this.getClass().getResource("/back-icon.png")));
		btnNewButton.setBounds(44, 25, 25, 25);
		contentPane.add(btnNewButton);

	}
}
