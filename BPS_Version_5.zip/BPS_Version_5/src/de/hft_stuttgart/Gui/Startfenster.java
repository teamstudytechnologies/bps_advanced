package de.hft_stuttgart.Gui;

import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import de.hft_stuttgart.BusinessObjects.Person;
import de.hft_stuttgart.DBAccess.DB_Personen;
import java.awt.Toolkit;
import java.sql.Connection;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class Startfenster extends JFrame {

	private JPanel contentPane;
	private JTextField Username;
	private JTextField Passwort;

	static Connection conn = null;
	static String url = "jdbc:mysql://193.196.143.168:3306/";
	static String dbName = "ohw8_gruppe2";
	static String driver = "com.mysql.jdbc.Driver";
	static String userName = "ohw8_gruppe2";
	static String password = "studytech";

	public static Person eingeloggtePerson;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Startfenster frame = new Startfenster();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Startfenster() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JLabel logo = new JLabel(new ImageIcon(this.getClass().getResource("/Study_Technologies_logo.png")));
		logo.setBounds(275, 0, 200, 200);
		contentPane.add(logo);

		Username = new JTextField();
		Username.setBounds(275, 325, 200, 25);
		contentPane.add(Username);
		Username.setColumns(10);

		Passwort = new JPasswordField();
		Passwort.setBounds(275, 360, 200, 25);
		contentPane.add(Passwort);
		Passwort.setColumns(10);

		JLabel xing = new JLabel("");
		xing.setIcon(new ImageIcon(this.getClass().getResource("/xing_logo.png")));
		xing.setBounds(280, 250, 50, 50);
		contentPane.add(xing);

		JLabel google = new JLabel("");
		google.setIcon(new ImageIcon(this.getClass().getResource("/google_logo.png")));
		google.setBounds(350, 250, 50, 50);
		contentPane.add(google);

		JLabel facebook = new JLabel("");
		facebook.setIcon(new ImageIcon(this.getClass().getResource("/facebook_logo.png")));
		facebook.setBounds(420, 250, 50, 50);
		contentPane.add(facebook);

		JButton Account_erstellen = new JButton("Neuen Account erstellen");
		Account_erstellen.setForeground(Color.WHITE);
		Account_erstellen.setFont(new Font("Tahoma", Font.BOLD, 11));
		Account_erstellen.setBackground(new Color(30, 144, 255));
		Account_erstellen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();
				Registration gui2 = new Registration();
				gui2.setVisible(true);

			}
		});
		Account_erstellen.setBounds(275, 440, 200, 25);
		contentPane.add(Account_erstellen);

		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(160, 325, 75, 25);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Passwort:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(160, 360, 75, 25);
		contentPane.add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(233, 53, 120));
		btnNewButton.setBounds(325, 400, 100, 25);
		contentPane.add(btnNewButton);

		JLabel lblBpsAdvanced = new JLabel("BPS Advanced");
		lblBpsAdvanced.setHorizontalAlignment(SwingConstants.CENTER);
		lblBpsAdvanced.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBpsAdvanced.setBounds(300, 215, 150, 25);
		contentPane.add(lblBpsAdvanced);

		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				DB_Personen.getPersonen();

				boolean a = false;
				loop: for (int i = 0; i < DB_Personen.listPerson.size(); i++) {

					if (Username.getText().equals(DB_Personen.listPerson.get(i).getEmail().toString())
							&& Passwort.getText().equals(DB_Personen.listPerson.get(i).getPasswort().toString())) {

						eingeloggtePerson = DB_Personen.listPerson.get(i);

						a = true;

						switch (DB_Personen.listPerson.get(i).getStatus()) {
						case "Student":
							dispose();
							BPS_anmelden anmelden = new BPS_anmelden();
							anmelden.setVisible(true);

							break loop;

						case "Professor":
							dispose();
							Eintragung_Studierende gui = new Eintragung_Studierende();
							gui.setVisible(true);
							break loop;
						default:
							break;
						}

					}

				}

				if (a == false) {
					JOptionPane.showMessageDialog(null, "Ung�ltiger Benutzername und/oder Passwort");
				}

			}
		});

	}
}
