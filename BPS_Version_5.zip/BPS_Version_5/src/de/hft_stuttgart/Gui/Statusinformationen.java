package de.hft_stuttgart.Gui;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Statusinformationen extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Statusinformationen frame = new Statusinformationen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Statusinformationen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 240, 224));
		panel_1.setBounds(75, 25, 600, 450);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Statusinformation-Betreuer Zuweisung:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(15, 15, 400, 25);
		panel_1.add(lblNewLabel_1);
		
		JButton btnNchsteSeite = new JButton("N\u00E4chste Seite");
		btnNchsteSeite.setForeground(Color.WHITE);
		btnNchsteSeite.setBackground(new Color(30, 144, 255));
		btnNchsteSeite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				Gui4 gui4 = new Gui4();
				gui4.setVisible(true);
			}
		});
		btnNchsteSeite.setBounds(438, 396, 132, 23);
		panel_1.add(btnNchsteSeite);
		
		
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				BPS_anmelden gui1 = new BPS_anmelden();
				gui1.setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(255, 236, 215));
		btnNewButton.setBackground(new Color(255, 236, 215));
		btnNewButton.setIcon(new ImageIcon(this.getClass().getResource("/back-icon.png")));
		btnNewButton.setBounds(44, 25, 25, 25);
		contentPane.add(btnNewButton);
		
		JLabel bps_status = new JLabel("BPS eingetragen");
		bps_status.setHorizontalAlignment(SwingConstants.CENTER);
		bps_status.setBounds(15, 75, 200, 60);
		bps_status.setBackground(Color.GREEN);
		bps_status.setOpaque(true);
		panel_1.add(bps_status);
		
		if(Startfenster.eingeloggtePerson.getPraktikum_id()==0) {
			bps_status.setText("BPS nicht eingetragen");
			bps_status.setBackground(Color.RED);
			bps_status.setOpaque(true);

		}
		
		JLabel betreuer_status = new JLabel("Betreuer zugewiesen");
		betreuer_status.setHorizontalAlignment(SwingConstants.CENTER);
		betreuer_status.setBounds(15, 175, 200, 60);
		panel_1.add(betreuer_status);
		betreuer_status.setBackground(Color.GREEN);
		betreuer_status.setOpaque(true);
		panel_1.add(betreuer_status);
		
		if(Startfenster.eingeloggtePerson.getBetreuer_id()==0) {
			betreuer_status.setText("Betreuer nicht zugewiesen");
			betreuer_status.setBackground(Color.RED);
			betreuer_status.setOpaque(true);

		}
		
		
		
	}
}
