package de.hft_stuttgart.Gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

import de.hft_stuttgart.BusinessObjects.*;
import de.hft_stuttgart.DBAccess.DB_Personen;

public class Studierenden_kontaktieren extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Studierenden_kontaktieren frame = new Studierenden_kontaktieren();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Studierenden_kontaktieren() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 750, 550);
		setTitle("BPS Advanced");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("/Study_Technologies_icon.png")));

		contentPane.setBackground(new Color(255, 236, 215));
		contentPane.setLayout(null);

		JLabel lblBetreuerKontaktieren = new JLabel("Studierenden kontaktieren:");
		lblBetreuerKontaktieren.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblBetreuerKontaktieren.setHorizontalAlignment(SwingConstants.LEFT);
		lblBetreuerKontaktieren.setBounds(10, 25, 325, 25);
		contentPane.add(lblBetreuerKontaktieren);

		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setBounds(10, 106, 714, 318);
		contentPane.add(textArea);

		JButton btnSenden = new JButton("Senden");
		btnSenden.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();
				Gui6 gui6 = new Gui6();
				gui6.setVisible(true);

			}
		});
		btnSenden.setBounds(635, 435, 89, 23);
		contentPane.add(btnSenden);

		List<Person> listStudent = new ArrayList<Person>();
		String[] alleStudentenMitVornameUndNachname;
		for (int i = 0; i < DB_Personen.listPerson.size(); i++) {
			if (DB_Personen.listPerson.get(i).getStatus().equals("Student")) {
				listStudent.add(DB_Personen.listPerson.get(i));
			}
		}

		JComboBox comboBox = new JComboBox();		
		comboBox.setModel(new DefaultComboBoxModel(listStudent.toArray()));
		comboBox.setBounds(10, 55, 714, 25);
		contentPane.add(comboBox);
	}
}
