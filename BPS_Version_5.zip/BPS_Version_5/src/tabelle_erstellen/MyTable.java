package tabelle_erstellen;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;


public class MyTable extends AbstractTableModel {

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub

		return 5;

	}

	@Override
	public Object getValueAt(int row, int col) {


		List<Person> listPerson = new ArrayList<>();
		
		listPerson.add(new Person("Eugen", "Ullmann", 1));
		listPerson.add(new Person("Sascha", "M�ller", 2));
		listPerson.add(new Person("Max", "Ullmann", 3));
		listPerson.add(new Person("Eugen", "Ulbricht", 4));
		listPerson.add(new Person("Daniel", "Mustermann", 5));
		
		return col==0?listPerson.get(row).vorname:col==1?listPerson.get(row).nachname:listPerson.get(row).nummer;
		
	}

	
	
	/*@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

		 List<Person> listPerson = new ArrayList<>();
		
			listPerson.add(new Person("Eugen", "Ullmann", 1));
			listPerson.add(new Person("Eugen", "Ullmann", 2));
			listPerson.add(new Person("Eugen", "Ullmann", 3));
			listPerson.add(new Person("Eugen", "Ullmann", 4));
			listPerson.add(new Person("Eugen", "Ullmann", 5));
		
		
		for (int i = 0; i < getRowCount(); i++) {

			for (int j = 0; j < getColumnCount(); j++) {

				if (getColumnCount() == 0) {

					aValue = listPerson.get(getRowCount()).vorname;

				} else if (getColumnCount() == 1) {
					aValue = listPerson.get(getRowCount()).nachname;

				}

				else if (getColumnCount() == 2) {
					aValue = listPerson.get(getRowCount()).nummer;

				}

			}

		}

	}*/

}
